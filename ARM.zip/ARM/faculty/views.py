from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from Alumini.models import *


def Home(request):
    if Verification(request):
        return render(request, 'faculty/Mlogin.html', {'login': 'active'})
    data = Carousel.objects.all().order_by('id')
    print(data)
    return render(request, 'faculty/Mhome.html', {'home': 'active', 'data': data})


def MasterProfile(request):
    if Verification(request):
        return render(request, 'faculty/Mlogin.html', {'login': 'active'})
    if request.method == 'GET':
        profile_id = request.GET['id']
        data = Alumini.objects.filter(id=profile_id)
        return render(request, 'faculty/Mmasterprofile.html', {'data': data, 'Student': 'active'})
    else:
        return HttpResponse("<h1>404 -- Not Found </h1>")


def Ongoing(request):
    if Verification(request):
        return render(request, 'faculty/Mlogin.html', {'login': 'active'})
    data = Carousel.objects.all().order_by('id')
    return render(request, 'faculty/Mongoing.html', {'ongoing': 'active', 'data': data})


def Resolve(request):
    if Verification(request):
        return render(request, 'faculty/Mlogin.html', {'login': 'active'})
    data = ContactUs.objects.all().order_by('resolve_status', 'id')
    return render(request, 'faculty/Mresolve.html', {'resolve': 'active', 'data': data})


def ResolveQ(request):
    if Verification(request):
        return render(request, 'faculty/Mlogin.html', {'login': 'active'})
    if request.method == 'GET':
        profile_id = request.GET['id']
        data = ContactUs.objects.filter(id=profile_id)
        return render(request, 'faculty/MResolveQ.html', {'data': data, 'resolve': 'active'})
    else:
        return HttpResponse("<h1>404 -- Not Found </h1>")


def ResolveStatus(request):
    if Verification(request):
        return render(request, 'faculty/Mlogin.html', {'login': 'active'})
    if request.method == 'GET':
        profile_id = request.GET['id']
        ContactUs.objects.filter(id=profile_id).update(
            resolve_status='true')
        return Resolve(request)
    else:
        return HttpResponse("<h1>404 -- Not Found </h1>")


def VerificationStatus(request):
    if Verification(request):
        return render(request, 'faculty/Mlogin.html', {'login': 'active'})
    if request.method == 'GET':
        profile_id = request.GET['id']
        data = Alumini.objects.get(id=profile_id)
        if data.verification_status == 'active':
            Alumini.objects.filter(id=profile_id).update(
                verification_status='disable')
            msg = 'Student deativated'
        if data.verification_status == 'disable':
            Alumini.objects.filter(id=profile_id).update(
                verification_status='active')
            msg = 'Student Activated'
        data = Alumini.objects.filter(id=profile_id)
        return Students(request)
    else:
        return HttpResponse("<h1>404 -- Not Found </h1>")


def Students(request):
    if Verification(request):
        return render(request, 'faculty/Mlogin.html', {'login': 'active'})
    id = request.session['faculty_id']
    data = Faculty.objects.get(id=id)
    branch = data.branch
    data = Alumini.objects.filter(branch=branch).order_by('id')
    print(data)
    return render(request, 'faculty/MyStudent.html', {'Student': 'active', 'data': data})


def FLogin(request):
    if request.method == 'POST':
        email = request.POST['email']
        data = Faculty.objects.filter(email=email)
        counts = Faculty.objects.filter(email=email).count()
        if counts == 1:
            data = data[0]
            if data.password == request.POST['password']:
                request.session['faculty_id'] = data.id
                request.session['faculty_email'] = data.email
                return Home(request)
            else:
                msg = "Email or Password  is invalid"
                return render(request, 'faculty/Mlogin.html', {'msg': msg, 'login': 'active'})
        else:
            msg = "Email or Password  is invalid"
            return render(request, 'faculty/Mlogin.html', {'msg': msg, 'login': 'active'})
    else:
        return render(request, 'faculty/Mlogin.html', {'login': 'active'})


def FLogout(request):
    try:
        request.session['faculty_id'] = None
        request.session['faculty_email'] = None
    except KeyError:
        pass
    return Home(request)


def Verification(request):
    if request.session.get('faculty_id') != None:
        faculty_id = request.session['faculty_id']
        email = request.session['faculty_email']
        if faculty_id == None:
            return render(request, 'faculty/Mlogin.html', {'login': 'active'})
        data = Faculty.objects.get(id=faculty_id)
        if data.email == email and data.id == faculty_id:
            return False
    else:
        return True
