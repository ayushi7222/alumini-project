from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.Home, name='home page'),
    path('Flogin', views.FLogin),
    path('Flogout', views.FLogout),
    path('mystudents', views.Students),
    path('masterprofile', views.MasterProfile),
    path('verification_status', views.VerificationStatus),
    path('ongoing', views.Ongoing),
    path('resolve', views.Resolve),
    path('ResolveQ', views.ResolveQ),
    path('resolve_status', views.ResolveStatus),
]
