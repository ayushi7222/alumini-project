from django.apps import AppConfig


class AluminiConfig(AppConfig):
    name = 'Alumini'
