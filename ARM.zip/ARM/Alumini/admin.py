from django.contrib import admin
from Alumini.models import *

readonly_fields = ('date',)

# Register your models here.
admin.site.register(Alumini)
admin.site.register(Faculty)
admin.site.register(BranchList)
admin.site.register(ContactUs)
admin.site.register(Mail)
admin.site.register(Carousel)
admin.site.register(ArmAdmin)
