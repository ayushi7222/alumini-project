
from django.urls import path
from . import views

urlpatterns = [
    path('', views.Home, name='home page'),
    path('ongoing', views.Ongoing),
    path('contact', views.Contact),
    path('queries', views.Queries),
    path('signup', views.SignUp),
    path('login', views.Login),
    path('logout', views.Logout),


]

handler404 = views.handler404
handler500 = views.handler500
