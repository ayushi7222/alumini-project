from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse
from Alumini.models import *
from django.views.decorators.csrf import csrf_exempt
from django.conf import settings

# Create your views here.


def Home(request):
    if Verification(request):
        return render(request, 'login.html', {'login': 'active'})
    data = Carousel.objects.all().order_by('id')
    return render(request, 'Uhome.html', {'home': 'active', 'data': data})


def Ongoing(request):
    if Verification(request):
        return render(request, 'login.html', {'login': 'active'})
    data = Carousel.objects.all().order_by('id')
    return render(request, 'ongoing.html', {'ongoing': 'active', 'data': data})


def Queries(request):
    if Verification(request):
        return render(request, 'login.html', {'login': 'active'})
    data = ContactUs.objects.filter(
        user_email=request.session['student_email']).order_by('resolve_status', 'id')
    return render(request, 'queries.html', {'queries': 'active', 'data': data})


def SignUp(request):
    branch_list = BranchList.objects.all().order_by('branch')
    if request.method == 'POST':
        user_name = request.POST['user_name']
        email = request.POST['email']
        mobile = request.POST['mobile']
        branch = request.POST['branch']
        computer_code = request.POST['computer_code']
        enrollment_no = request.POST['enrollment_no']
        password = request.POST['password']
        msg = ""
        emailcounts = Alumini.objects.filter(email=email).count()
        mobilecount = Alumini.objects.filter(mobile=mobile).count()
        if user_name == None:
            msg = 'blank name invalid'
        elif email == None:
            msg = 'blank email invalid'
        elif mobile == None:
            msg = 'blank mobile number invalid'
        elif password != request.POST['re_password']:
            msg = 'Password not match!'
        elif emailcounts == 1:
            msg = 'Email already exisit with other account!'
        elif mobilecount == 1:
            msg = 'Mobile number already exisit with other account!'
        if msg != "":
            return render(request, 'signup.html', {'msg': msg, 'signup': 'active', 'user_name': user_name, 'email': email, 'mobile': mobile, 'computer_code': computer_code, 'branch': branch, 'enrollment_no': enrollment_no, 'branch_list': branch_list})

        Alumini(alumini_name=user_name, email=email, mobile=mobile, computer_code=computer_code, enrollment_no=enrollment_no,
                branch=branch, password=password, verification_status='disable').save()
        msg = 'Account created wait for verify and then log in '
        return render(request, 'login.html', {'msg': msg, 'login': 'active', 'branch_list': BranchList})
    else:
        return render(request, 'signup.html', {'signup': 'active', 'branch_list': branch_list})


def Contact(request):
    if Verification(request):
        return render(request, 'login.html', {'login': 'active'})
    if request.method == 'POST':
        user_id = request.session['student_id']
        user = Alumini.objects.get(id=request.session['student_id'])
        email = user.email
        contact = user.mobile
        subject = request.POST['subject']
        message = request.POST['message']
        ContactUs(subject=subject, message=message,
                  user_email=email, user_contact=contact).save()
        msg = "compliment or complaint assigned succesfully"
        return render(request, 'Ucontact.html', {'contact': 'active', 'msg': msg})
    return render(request, 'Ucontact.html', {'contact': 'active'})


def Login(request):
    if request.method == 'POST':
        email = request.POST['email']
        data = Alumini.objects.filter(email=email)
        counts = Alumini.objects.filter(email=email).count()
        if counts == 1:
            data = data[0]
            if data.password == request.POST['password']:
                if data.verification_status == 'disable':
                    msg = 'Account Not Verifiesd yet'
                    return render(request, 'login.html', {'msg1': msg, 'login': 'active'})
                request.session['student_id'] = data.id
                request.session['student_email'] = data.email
                return Home(request)
            else:
                msg = "Email or Password  is invalid"
                return render(request, 'login.html', {'msg': msg, 'login': 'active'})
        else:
            msg = "Email or Password  is invalid"
            return render(request, 'login.html', {'msg': msg, 'login': 'active'})
    else:
        return render(request, 'login.html', {'login': 'active'})


def Logout(request):
    try:
        request.session['student_id'] = None
        request.session['student_email'] = None
    except KeyError:
        pass
    return Home(request)


def Verification(request):
    if request.session.get('student_id') != None:
        student_id = request.session['student_id']
        email = request.session['student_email']
        if student_id == None:
            return render(request, 'login.html', {'login': 'active'})
        data = Alumini.objects.get(id=student_id)
        if data.email == email and data.id == student_id:
            return False
    else:
        return True


def handler404(request, exception):
    return render(request, '404.html', status=404)


def handler500(request):
    return render(request, '500.html', status=500)
