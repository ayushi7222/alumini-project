from django.db import models
from django.utils.timezone import now
from io import BytesIO
from PIL import Image
from django.core.files import File


def compress(image):
    im = Image.open(image)
    im_io = BytesIO()
    im = im.convert('RGB')
    im = im.resize((400, 400))
    im.save(im_io, 'JPEG', quality=70)
    new_image = File(im_io, name=image.name)
    return new_image


class Carousel(models.Model):
    id = models.AutoField(primary_key=True)
    heading = models.CharField(max_length=80)
    details = models.CharField(max_length=500)
    image = models.ImageField(upload_to='images/')
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        new_image = compress(self.image)
        self.image = new_image
        super().save(*args, **kwargs)

    class Meta:
        db_table = "Carousel"

# Create your models here.


class Alumini(models.Model):
    id = models.AutoField(primary_key=True)
    alumini_name = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    mobile = models.CharField(max_length=15)
    computer_code = models.IntegerField(unique=True)
    enrollment_no = models.CharField(max_length=50)
    branch = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    verification_status = models.CharField(max_length=10)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "Alumini"


class Faculty(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    mobile = models.CharField(max_length=50)
    branch = models.CharField(max_length=50)
    password = models.CharField(max_length=50, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "Faculty"


class BranchList(models.Model):
    id = models.AutoField(primary_key=True)
    branch = models.CharField(max_length=50, unique=True)

    class Meta:
        db_table = "BranchList"


class ContactUs(models.Model):
    id = models.AutoField(primary_key=True)
    subject = models.TextField(null=True)
    message = models.TextField(null=True)
    user_email = models.CharField(max_length=50)
    user_contact = models.CharField(max_length=20)
    resolve_status = models.CharField(max_length=10)

    class Meta:
        db_table = "ContactUs"


class Mail(models.Model):
    id = models.AutoField(primary_key=True)
    subject = models.TextField(null=True)
    message = models.TextField(null=True)
    user_email = models.CharField(max_length=50)

    class Meta:
        db_table = "Mail"

################# admin - section


class ArmAdmin(models.Model):
    admin_id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    mobile = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "ArmAdmin"
