from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('', views.home, name='home page'),
    path('alogin', views.alogin),
    path('alogout', views.alogout),
    path('adminWidgets', views.adminWidgets),
    path('addBranch', views.addBranch, name='addBranch'),
    path('addFaculty', views.addFaculty, name='addFaculty'),
    path('addCarousel', views.addCarousel, name='addCarousel'),
    path('adminPanel', views.adminPanel, name='adminPanel'),
    path('DelCarousel', views.DelCarousel, name='DelCarousel'),

]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,
                          document_root=settings.MEDIA_ROOT)
