from django.apps import AppConfig


class ArmAdminConfig(AppConfig):
    name = 'ARM_Admin'
