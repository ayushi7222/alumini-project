from django.shortcuts import render
from django.http import HttpResponse, HttpResponseRedirect
from Alumini.models import *
import random

# Create your views here.


def home(request):
    if admin_verification(request):
        return render(request, 'admin/alogin.html')
    data = Carousel.objects.all().order_by('id')
    return render(request, 'admin/ahome.html', {'admin_home': 'active', 'data': data})


def DelCarousel(request):
    if admin_verification(request):
        return render(request, 'admin/alogin.html')
    if request.method == 'GET':
        id = request.GET['id']
        Carousel.objects.get(id=id).delete()
    return home(request)


def adminWidgets(request):
    if admin_verification(request):
        return render(request, 'admin/login.html')
    return render(request, 'admin/admin_widgets.html', {'data': 'data', 'adminWidgets': 'active'})


def adminPanel(request):
    if admin_verification(request):
        return render(request, 'admin/login.html')
    branch_list = BranchList.objects.all().order_by('branch')
    data = Faculty.objects.all().order_by('branch', 'name')
    try:
        table = request.GET['id']
        if table == 'facultyList':
            data = Faculty.objects.all().order_by('branch', 'name')
        else:
            data = Alumini.objects.filter(
                branch=table).order_by('branch', 'alumini_name')
        return render(request, 'admin/admin_panels.html', {'data': data, 'branch_list': branch_list, 'adminPanel': 'active', 'table': table})
    except KeyError:
        table = 'facultyList'
        return render(request, 'admin/admin_panels.html', {'data': data, 'branch_list': branch_list, 'adminPanel': 'active', 'table': table})
    table = 'facultyList'
    return render(request, 'admin/admin_panels.html', {'data': data, 'branch_list': branch_list, 'adminPanel': 'active', 'table': table})


def addCarousel(request):
    if admin_verification(request):
        return render(request, 'admin/login.html')
    if request.method == 'POST':
        title = request.POST['title']
        information = request.POST['information']
        if information == None and title == None:
            msg = 'blank title or discription is   invalid'
            return render(request, 'admin/add_carousel.html', {'msg': msg, 'addCarousel': 'active', 'title': title, 'price': price, 'information': information})
        x = random.randint(999, 10000)
        try:
            files = request.FILES['myfile']
            files.name = 'img'+str(x)+files.name
            image = files
        except KeyError:
            image = None
        Carousel(heading=title, details=information, image=image).save()
        return home(request)

    return render(request, 'admin/add_carousel.html')


def addBranch(request):
    if admin_verification(request):
        return render(request, 'admin/login.html')
    if request.method == 'POST':
        branch = request.POST['branch']

        count = BranchList.objects.filter(branch=branch).count()
        if count != 0:
            msg = 'Branch already exsist'
            data = BranchList.objects.all().order_by('branch')
            return render(request, 'admin/admin_add_branch.html', {'data': data, 'addBranch': 'active', 'msg': msg})
        BranchList(branch=branch).save()
        msg = str(branch) + ' is succesfully added'
        data = BranchList.objects.all().order_by('branch')
        return render(request, 'admin/admin_add_branch.html', {'data': data, 'addBranch': 'active', 'msg1': msg})
    data = BranchList.objects.all().order_by('branch')
    return render(request, 'admin/admin_add_branch.html', {'data': data, 'addBranch': 'active'})


def addFaculty(request):
    if admin_verification(request):
        return render(request, 'admin/login.html')
    branch_list = BranchList.objects.all().order_by('branch')
    if request.method == 'POST':
        user_name = request.POST['user_name']
        email = request.POST['email']
        mobile = request.POST['mobile']
        branch = request.POST['branch']
        print(branch)
        password = request.POST['password']
        msg = ""
        if user_name == None:
            msg = 'blank name invalid'
        elif email == None:
            msg = 'blank email invalid'
        elif mobile == None or len(mobile) <= 9:
            msg = 'blank mobile number invalid'
        elif len(password) <= 7:
            msg = 'Password too short!'
        elif password != request.POST['re_password']:
            msg = 'Password not match!'
        if msg != "":
            return render(request, 'admin/admin_addfaculty.html', {'msg': msg, 'user_name': user_name, 'email': email, 'mobile': mobile, 'addFaculty': 'active', 'branch_list': branch_list})
        emailcounts = Faculty.objects.filter(email=email).count()
        mobilecount = Faculty.objects.filter(mobile=mobile).count()
        if emailcounts == 1:
            msg = 'Email already exisit with other account!'
            return render(request, 'admin/admin_addfaculty.html', {'msg': msg, 'user_name': user_name, 'email': email, 'mobile': mobile, 'addFaculty': 'active', 'branch_list': branch_list})
        if mobilecount == 1:
            msg = 'Mobile number already exisit with other account!'
            return render(request, 'admin/admin_addfaculty.html', {'msg': msg, 'user_name': user_name, 'email': email, 'mobile': mobile, 'addFaculty': 'active', 'branch_list': branch_list})
        Faculty(name=user_name, email=email, mobile=mobile,
                branch=branch, password=password).save()
        msg = 'Account created succesfully '
        return render(request, 'admin/admin_addfaculty.html', {'msg1': msg, 'addManager': 'active', 'branch_list': branch_list})
    else:
        return render(request, 'admin/admin_addfaculty.html', {'addFaculty': 'active', 'branch_list': branch_list})
    return render(request, 'admin/admin_addfaculty.html', {'data': 'data', 'addFaculty': 'active', 'branch_list': branch_list})


def alogin(request):
    if request.method == 'POST':
        email = request.POST['email']
        data = ArmAdmin.objects.filter(email=email)
        counts = ArmAdmin.objects.filter(email=email).count()
        if counts == 1:
            data = data[0]
            if data.password == request.POST['password']:
                request.session['admin_id'] = data.admin_id
                request.session['admin_email'] = data.email
                return home(request)
            else:
                msg = "Email or Password  is invalid"
                return render(request, 'admin/alogin.html', {'msg': msg})
        else:
            msg = "Email or Password  is invalid"
            return render(request, 'admin/alogin.html', {'msg': msg})
    else:
        return render(request, 'admin/alogin.html')


def alogout(request):
    try:
        request.session['admin_id'] = None
        request.session['admin_email'] = None
    except KeyError:
        pass
    return home(request)


def admin_verification(request):
    if request.session.get('admin_id') != None:
        admin_id = request.session['admin_id']
        email = request.session['admin_email']
        if admin_id == None:
            return render(request, 'admin/alogin.html')
        data = ArmAdmin.objects.get(admin_id=admin_id)
        if data.email == email and data.admin_id == admin_id:
            return False
    else:
        return True
